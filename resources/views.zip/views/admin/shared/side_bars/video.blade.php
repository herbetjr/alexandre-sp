<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-camera" aria-hidden="true"></i> <span class="title">Home Page Video</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.videos') }}" class="nav-link ">  <span class="title">List Video languages</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.video') }}" class="nav-link ">  <span class="title">Add new Video language</span> </a></li>
    </ul>
</li>