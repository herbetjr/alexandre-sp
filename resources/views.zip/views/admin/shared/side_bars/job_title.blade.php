<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-font" aria-hidden="true"></i> <span class="title">Job Titles</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.job.titles') }}" class="nav-link "> <span class="title">List Job Titles</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.job.title') }}" class="nav-link "> <span class="title">Add new Job Title</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.job.titles') }}" class="nav-link "> <span class="title">Sort Job Titles</span> </a> </li>
    </ul>
</li>